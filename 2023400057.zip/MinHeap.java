import java.util.ArrayList;

/**
 * Represents a state in the Dijkstra search (Host + path cost).
 */
class PathNode implements Comparable<PathNode> {
    public Host host;
    public int hostIndex;
    public double distance;
    public int stepCount;
    public PathNode parent;
    private static final double EPSILON = 1e-9; // Threshold for double comparison

    public PathNode(Host host, int hostIndex, double distance, int stepCount, PathNode parent) {
        this.host = host;
        this.hostIndex = hostIndex;
        this.distance = distance;
        this.stepCount = stepCount;
        this.parent = parent;
    }

    /**
     * Comparison logic: Priority given to distance, then step count, then host index.
     */
    @Override
    public int compareTo(PathNode o) {
        if (o == null) return -1;

        // Distance comparison using epsilon to handle precision
        double d = this.distance - o.distance;
        if (d > EPSILON) return 1;
        if (d < -EPSILON) return -1;

        // Tie-breaker: prefer fewer steps
        if (this.stepCount != o.stepCount)
            return Integer.compare(this.stepCount, o.stepCount);

        // Ultimate tie-breaker: unique host index
        return Integer.compare(this.hostIndex, o.hostIndex);
    }
}

/**
 * Custom Min-Priority Queue implementation for PathNodes.
 */
public class MinHeap {
    private final ArrayList<PathNode> heap = new ArrayList<>();

    public boolean isEmpty() {
        return heap.isEmpty();
    }

    public void add(PathNode node) {
        heap.add(node);
        siftUp(heap.size() - 1);
    }

    /**
     * Removes and returns the node with the lowest distance/priority.
     */
    public PathNode poll() {
        if (heap.isEmpty()) return null;

        PathNode min = heap.get(0);
        PathNode last = heap.remove(heap.size() - 1);

        if (!heap.isEmpty()) {
            heap.set(0, last);
            siftDown(0);
        }
        return min;
    }

    // Moves the element at index i up to maintain heap property
    private void siftUp(int i) {
        while (i > 0) {
            int p = (i - 1) / 2;
            if (heap.get(i).compareTo(heap.get(p)) < 0) {
                swap(i, p);
                i = p;
            } else break;
        }
    }

    // Moves the element at index i down to maintain heap property
    private void siftDown(int i) {
        int n = heap.size();
        while (true) {
            int l = 2 * i + 1;
            int r = 2 * i + 2;
            int s = i;

            if (l < n && heap.get(l).compareTo(heap.get(s)) < 0) s = l;
            if (r < n && heap.get(r).compareTo(heap.get(s)) < 0) s = r;

            if (s != i) {
                swap(i, s);
                i = s;
            } else break;
        }
    }

    private void swap(int i, int j) {
        PathNode t = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, t);
    }
}
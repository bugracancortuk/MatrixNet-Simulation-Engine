public final class MinHeapInt {
    private int[] heap;         // Stores host/state indices
    private double[] key;       // Stores priority values (distances)
    private int size;
    private int[] position;     // Tracks index of each state within the heap array
    private int[] inHeapToken;  // Version tracking for membership check
    private int currentToken;   // Current session ID for O(1) heap resets

    public MinHeapInt(int[] position, int[] inHeapToken, int token) {
        this.position = position;
        this.inHeapToken = inHeapToken;
        this.currentToken = token;
        heap = new int[256];
        key = new double[256];
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns the lowest key value without removing the element.
     */
    public double peekMinKey() {
        return size == 0 ? Double.POSITIVE_INFINITY : key[0];
    }

    /**
     * Adds a new state or decreases the key of an existing state.
     */
    public void addOrUpdate(int state, double dist) {
        // If state is already in the heap, update it if the new distance is smaller
        if (inHeapToken[state] == currentToken) {
            int i = position[state];
            if (key[i] > dist) {
                key[i] = dist;
                siftUp(i, dist);
            }
            return;
        }

        // Resize arrays if capacity is reached
        int i = size;
        if (i == heap.length) {
            int newCap = heap.length << 1;
            int[] nh = new int[newCap];
            double[] nk = new double[newCap];
            System.arraycopy(heap, 0, nh, 0, size);
            System.arraycopy(key, 0, nk, 0, size);
            heap = nh;
            key = nk;
        }

        // Insert as new leaf and bubble up
        heap[i] = state;
        key[i] = dist;
        position[state] = i;
        inHeapToken[state] = currentToken;
        size++;
        siftUp(i, dist);
    }

    // Moves the element up in the 4-ary heap structure
    private void siftUp(int i, double dist) {
        int state = heap[i];
        while (i > 0) {
            int p = (i - 1) >>> 2; // Parent index in a 4-ary heap
            if (key[p] <= dist) break;
            heap[i] = heap[p];
            key[i] = key[p];
            position[heap[i]] = i;
            i = p;
        }
        heap[i] = state;
        key[i] = dist;
        position[state] = i;
    }

    /**
     * Removes and returns the state with the minimum key value.
     */
    public int poll() {
        int res = heap[0];
        inHeapToken[res] = 0; // Mark as removed
        size--;

        if (size > 0) {
            int last = heap[size];
            double lastKey = key[size];
            siftDown(0, last, lastKey);
        }
        return res;
    }

    // Moves the element down by comparing with its 4 potential children
    private void siftDown(int i, int lastState, double lastKey) {
        while (true) {
            int c1 = (i << 2) + 1; // Index of the first child
            if (c1 >= size) break;

            int minChild = c1;
            double minKey = key[c1];

            // Find the smallest among the (up to) 4 children
            for (int k = 1; k < 4; k++) {
                int ck = c1 + k;
                if (ck < size && key[ck] < minKey) {
                    minChild = ck;
                    minKey = key[ck];
                }
            }

            if (minKey >= lastKey) break;

            heap[i] = heap[minChild];
            key[i] = minKey;
            position[heap[i]] = i;
            i = minChild;
        }
        heap[i] = lastState;
        key[i] = lastKey;
        position[lastState] = i;
    }
}
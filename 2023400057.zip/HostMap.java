import java.util.ArrayList;

/**
 * A custom HashMap implementation using separate chaining for Host storage.
 */
public class HostMap {
    private static final int CAP = 200003; // Prime number for better distribution

    private static class Node {
        Host h;
        Node next;
        Node(Host h, Node n) {
            this.h = h;
            this.next = n;
        }
    }

    private final Node[] table = new Node[CAP];
    private int size = 0;
    private ArrayList<Host> cache;   // Caches the list of all hosts
    private boolean dirty = true;    // Tracks if cache needs refreshing

    // Standard hash function to map a key to a table index
    private int idx(String key) {
        return (key.hashCode() & 0x7fffffff) % CAP;
    }

    public void put(String key, Host value) {
        int i = idx(key);
        for (Node n = table[i]; n != null; n = n.next) {
            if (n.h.id.equals(key)) {
                n.h = value;
                dirty = true;
                return;
            }
        }
        // Insert new node at the head of the chain
        table[i] = new Node(value, table[i]);
        size++;
        dirty = true;
    }

    public Host get(String key) {
        int i = idx(key);
        for (Node n = table[i]; n != null; n = n.next) {
            if (n.h.id.equals(key)) {
                return n.h;
            }
        }
        return null;
    }

    public Host remove(String key) {
        int i = idx(key);
        Node prev = null;
        Node cur = table[i];
        while (cur != null) {
            if (cur.h.id.equals(key)) {
                if (prev == null) table[i] = cur.next;
                else prev.next = cur.next;

                size--;
                dirty = true;
                return cur.h;
            }
            prev = cur;
            cur = cur.next;
        }
        return null;
    }

    public int size() {
        return size;
    }

    /**
     * Returns all hosts in the map. Uses a cached list if the data hasn't changed.
     */
    public ArrayList<Host> getAllValues() {
        if (!dirty && cache != null) {
            return cache;
        }

        ArrayList<Host> all = new ArrayList<>(size);
        for (Node n : table) {
            Node current = n;
            while (current != null) {
                all.add(current.h);
                current = current.next;
            }
        }
        cache = all;
        dirty = false;
        return all;
    }
}
import java.util.ArrayList;

/**
 * Implements an optimized multi-objective Dijkstra search for network routing.
 * Uses a state-space approach where each state is a pair of (Host, StepCount).
 */
public class Routing {

    private static final int MAX_STEPS = 60; // Max depth to prevent infinite cycles or excessive search
    private static final int PARETO_K = 4;   // Max number of non-dominated states to track per host

    private static ArrayList<Host> hosts;
    private static int hostCount;
    private static int stride; // Used for 1D mapping of 2D state space (hostIndex * stride + stepCount)

    private static double[] dist;
    private static int[] parent;
    private static int[] visit;

    // Pareto frontier arrays: Tracks multiple optimal paths (Trade-off between steps and latency)
    private static int[][] paretoStep;
    private static double[][] paretoCost;
    private static int[] paretoSize;

    // Memory management: Token-based resets for O(1) array initialization
    private static int[] position;
    private static int[] inHeapToken;
    private static int token = 1;

    private static StringBuilder sb = new StringBuilder(512);

    public static String findRoute(HostMap network, Host source, Host destination) {
        return findRoute(network, source, destination, 0, 0.0);
    }

    /**
     * Finds the optimal route considering latency, step count (lambda penalty), and bandwidth constraints.
     */
    public static String findRoute(
            HostMap network,
            Host source,
            Host destination,
            int minBandwidth,
            double lambda
    ) {

        if (source == destination) {
            sb.setLength(0);
            sb.append("Optimal route ").append(source.id).append(" -> ").append(destination.id)
                    .append(": ").append(source.id).append(" (Latency = 0ms)");
            return sb.toString();
        }

        // Lazy initialization: Resize global arrays only when the network map size changes
        int netSize = network.size();
        if (hosts == null || hostCount != netSize) {
            hosts = network.getAllValues();
            hostCount = netSize;
            for (int i = 0; i < hostCount; i++) hosts.get(i).index = i;

            stride = MAX_STEPS + 1;
            int total = hostCount * stride;

            dist = new double[total];
            parent = new int[total];
            visit = new int[total];
            position = new int[total];
            inHeapToken = new int[total];

            paretoStep = new int[hostCount][PARETO_K];
            paretoCost = new double[hostCount][PARETO_K];
            paretoSize = new int[hostCount];
        }

        token++; // Fast reset: values with visit[i] < token are considered unvisited
        for (int i = 0; i < hostCount; i++) paretoSize[i] = 0;

        int src = source.index;
        int dst = destination.index;
        int start = src * stride;

        dist[start] = 0;
        parent[start] = -1;
        visit[start] = token;

        // Initialize source Pareto state
        paretoStep[src][0] = 0;
        paretoCost[src][0] = 0;
        paretoSize[src] = 1;

        MinHeapInt pq = new MinHeapInt(position, inHeapToken, token);
        pq.addOrUpdate(start, 0);

        boolean useLambda = lambda > 0;
        int bestState = -1;

        while (!pq.isEmpty()) {
            int state = pq.poll();
            int u = state / stride;
            int step = state - u * stride;
            double baseDist = dist[state];

            if (u == dst) {
                bestState = state;
                break;
            }

            if (step == MAX_STEPS) continue;

            Host h = hosts.get(u);
            ArrayList<Link> links = h.outgoingLinks;
            if (links == null) continue;

            int clearance = h.clearance;
            int nextStep = step + 1;

            for (Link e : links) {
                // Constraint checks: security clearance, bandwidth, and sealed status
                if (e.isSealed || e.bandwidth < minBandwidth || clearance < e.firewallRating) continue;

                int v = e.destination.index;
                int nextState = v * stride + nextStep;

                // Path cost calculation: Latency + lambda * steps (optional penalty)
                double nd = baseDist + e.latency;
                if (useLambda) nd += lambda * step;

                // --- PARETO DOMINANCE CHECK ---
                // Prune paths that are worse in both steps and cost than an existing path
                boolean dominated = false;
                int ps = paretoSize[v];
                for (int j = 0; j < ps; j++) {
                    if (paretoStep[v][j] <= nextStep && paretoCost[v][j] <= nd) {
                        dominated = true;
                        break;
                    }
                }
                if (dominated) continue;

                // Filter out existing states that are now dominated by this new state
                int write = 0;
                for (int j = 0; j < ps; j++) {
                    if (!(paretoStep[v][j] >= nextStep && paretoCost[v][j] >= nd)) {
                        paretoStep[v][write] = paretoStep[v][j];
                        paretoCost[v][write] = paretoCost[v][j];
                        write++;
                    }
                }

                if (write < PARETO_K) {
                    paretoStep[v][write] = nextStep;
                    paretoCost[v][write] = nd;
                    write++;
                }
                paretoSize[v] = write;

                // Standard Dijkstra relaxation for the current (Host, Step) state
                if (visit[nextState] != token || nd < dist[nextState]) {
                    dist[nextState] = nd;
                    parent[nextState] = state;
                    visit[nextState] = token;
                    pq.addOrUpdate(nextState, nd);
                }
            }
        }

        return formatResult(source, destination, bestState);
    }

    /**
     * Reconstructs the path from parent pointers and formats the final string.
     */
    private static String formatResult(Host source, Host destination, int bestState) {
        if (bestState == -1) {
            return "No route found from " + source.id + " to " + destination.id;
        }

        int len = 0;
        for (int s = bestState; s != -1; s = parent[s]) len++;

        int[] path = new int[len];
        int p = len - 1;
        for (int s = bestState; s != -1; s = parent[s]) path[p--] = s / stride;

        sb.setLength(0);
        sb.append("Optimal route ").append(source.id).append(" -> ").append(destination.id).append(": ");
        for (int i = 0; i < len; i++) {
            sb.append(hosts.get(path[i]).id);
            if (i + 1 < len) sb.append(" -> ");
        }
        sb.append(" (Latency = ").append((long) dist[bestState]).append("ms)");

        return sb.toString();
    }
}
import java.util.ArrayList;

public class Host {
    // Basic Properties
    public String id;
    public int clearance;
    public ArrayList<Link> outgoingLinks;

    // Graph Algorithm State
    public boolean visited;
    public Host parent;
    public int discoveryTime;
    public int lowLink;        // Used for Tarjan's/SCC algorithms
    public int heapIndex = -1; // Used for priority queue optimizations

    // Routing index (assigned by Routing.java)
    public int index;

    public Host(String id, int clearance) {
        this.id = id;
        this.clearance = clearance;
        this.outgoingLinks = new ArrayList<>();
        this.index = -1;
        resetAlgoFlags();
    }

    /**
     * Resets algorithm-specific flags for fresh graph traversals.
     */
    public void resetAlgoFlags() {
        this.visited = false;
        this.parent = null;
        this.discoveryTime = 0;
        this.lowLink = 0;
    }
}
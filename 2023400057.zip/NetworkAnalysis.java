import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

/**
 * Provides analytical tools to evaluate network topology, connectivity, and performance.
 */
public class NetworkAnalysis {

    private HostMap network;

    public NetworkAnalysis(HostMap network) {
        this.network = network;
    }

    /**
     * Aggregates network statistics and writes a formatted summary to the output.
     */
    public void generateReport(int totalBackdoors, PrintWriter pw) {
        try {
            ArrayList<Host> hosts = network.getAllValues();
            if (hosts == null) hosts = new ArrayList<>();

            int totalHosts = hosts.size();
            int components = 0;
            int visitedCount = 0;
            CycleTracker cycleTracker = new CycleTracker();

            // Prepare hosts for traversal
            for (Host h : hosts) if (h != null) h.resetAlgoFlags();

            // Identify connected components and detect cycles via BFS
            for (Host h : hosts) {
                if (h != null && !h.visited) {
                    components++;
                    visitedCount += bfsComponent(h, cycleTracker);
                }
            }

            // Determine connectivity status
            String connectivity = (totalHosts == 0 || (visitedCount == totalHosts && components == 1))
                    ? "Connected" : "Disconnected";

            // Calculate aggregate performance and security metrics
            long totalBandwidth = 0;
            int bandwidthCount = 0;
            double totalClearance = 0;

            for (Host h : hosts) {
                if (h == null) continue;
                totalClearance += h.clearance;

                if (h.outgoingLinks != null) {
                    for (Link l : h.outgoingLinks) {
                        if (l == null || l.isSealed) continue;
                        totalBandwidth += l.bandwidth;
                        bandwidthCount++;
                    }
                }
            }

            String avgBandwidthStr = bandwidthCount > 0 ? formatDecimal((double) totalBandwidth / bandwidthCount) + "Mbps" : "0Mbps";
            String avgClearanceStr = totalHosts > 0 ? formatDecimal(totalClearance / totalHosts) : "0";

            pw.println("--- Resistance Network Report ---");
            pw.println("Total Hosts: " + totalHosts);
            pw.println("Total Unsealed Backdoors: " + totalBackdoors);
            pw.println("Network Connectivity: " + connectivity);
            pw.println("Connected Components: " + components);
            pw.println("Contains Cycles: " + (cycleTracker.hasCycle ? "Yes" : "No"));
            pw.println("Average Bandwidth: " + avgBandwidthStr);
            pw.println("Average Clearance Level: " + avgClearanceStr);

        } catch (Exception e) {
            pw.println("Some error occurred in oracle_report.");
        }
    }

    private String formatDecimal(double val) {
        return new BigDecimal(val).setScale(1, RoundingMode.HALF_UP).toString();
    }

    /**
     * Traverses a single component using BFS to count nodes and detect cycles.
     */
    private int bfsComponent(Host start, CycleTracker tracker) {
        if (start == null) return 0;

        ArrayList<Host> queue = new ArrayList<>();
        queue.add(start);
        int count = 0;
        int head = 0;

        start.visited = true;
        start.parent = null;

        while (head < queue.size()) {
            Host u = queue.get(head++);
            if (u == null) continue;
            count++;

            if (u.outgoingLinks == null) continue;

            for (Link l : u.outgoingLinks) {
                if (l == null || l.isSealed) continue;

                Host v = l.destination;
                if (v == null || v == u) continue;

                if (!v.visited) {
                    v.visited = true;
                    v.parent = u;
                    queue.add(v);
                } else if (v != u.parent) {
                    // If neighbor is visited and not the parent, a cycle exists
                    tracker.hasCycle = true;
                }
            }
        }
        return count;
    }

    /**
     * Counts the number of isolated sub-networks (components).
     */
    public int countComponents() {
        try {
            ArrayList<Host> hosts = network.getAllValues();
            if (hosts == null) return 0;

            for (Host h : hosts) if (h != null) h.resetAlgoFlags();

            int components = 0;
            CycleTracker tracker = new CycleTracker();
            for (Host h : hosts) {
                if (h != null && !h.visited) {
                    components++;
                    bfsComponent(h, tracker);
                }
            }
            return components;
        } catch (Exception e) {
            return 0;
        }
    }

    private static class CycleTracker {
        boolean hasCycle = false;
    }
}
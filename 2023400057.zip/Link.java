public class Link {
    // Connection endpoints
    public Host source;
    public Host destination;

    // Performance and security metrics
    public int latency;
    public int bandwidth;
    public int firewallRating;

    // Status flag for security or structural constraints
    public boolean isSealed;

    public Link(Host source, Host destination, int latency, int bandwidth, int firewallRating) {
        this.source = source;
        this.destination = destination;
        this.latency = latency;
        this.bandwidth = bandwidth;
        this.firewallRating = firewallRating;
        this.isSealed = false; // Default state is unsealed
    }
}
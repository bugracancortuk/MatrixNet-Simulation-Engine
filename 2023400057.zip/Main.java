import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * Main engine for the MatrixNet simulation.
 * Manages the network topology and processes user commands.
 */
public class Main {
    private static HostMap network = new HostMap();
    private static int totalBackdoors = 0;

    public static void main(String[] args) {
        String inputFile = args.length > 0 ? args[0] : "test_input";
        String outputFile = args.length > 1 ? args[1] : "output_file";

        // Setup I/O streams
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             PrintWriter pw = new PrintWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    processCommand(line.trim(), pw);
                }
            }
        } catch (IOException e) {
            System.err.println("File Error: " + e.getMessage());
        }
    }

    /**
     * Parses the command string and delegates to the appropriate handler.
     */
    private static void processCommand(String line, PrintWriter pw) {
        StringTokenizer st = new StringTokenizer(line);
        if (!st.hasMoreTokens()) return;

        String command = st.nextToken();
        try {
            switch (command) {
                case "spawn_host" -> handleSpawnHost(st, pw);
                case "link_backdoor" -> handleLinkBackdoor(st, pw);
                case "trace_route" -> handleTraceRoute(st, pw);
                case "oracle_report" -> handleOracleReport(pw);
                case "seal_backdoor" -> handleSealBackdoor(st, pw);
                case "simulate_breach" -> handleSimulateBreach(st, pw);
                case "scan_connectivity" -> handleScanConnectivity(pw);
            }
        } catch (Exception e) {
            pw.println("Some error occurred in " + command + ".");
        }
    }

    // Creates and adds a new host to the network map
    private static void handleSpawnHost(StringTokenizer st, PrintWriter pw) {
        try {
            String id = st.nextToken();
            int clearance = Integer.parseInt(st.nextToken());

            if (id.matches("[a-zA-Z0-9_]+") && network.get(id) == null) {
                network.put(id, new Host(id, clearance));
                pw.println("Spawned host " + id + " with clearance level " + clearance + ".");
            } else {
                pw.println("Some error occurred in spawn_host.");
            }
        } catch (Exception e) {
            pw.println("Some error occurred in spawn_host.");
        }
    }

    // Establishes a bidirectional link between two hosts
    private static void handleLinkBackdoor(StringTokenizer st, PrintWriter pw) {
        try {
            String uId = st.nextToken();
            String vId = st.nextToken();
            int latency = Integer.parseInt(st.nextToken());
            int bandwidth = Integer.parseInt(st.nextToken());
            int firewall = Integer.parseInt(st.nextToken());

            Host u = network.get(uId);
            Host v = network.get(vId);

            if (u != null && v != null && !uId.equals(vId)) {
                // Prevent duplicate links
                for (Link l : u.outgoingLinks) {
                    if (l.destination == v) {
                        pw.println("Some error occurred in link_backdoor.");
                        return;
                    }
                }
                u.outgoingLinks.add(new Link(u, v, latency, bandwidth, firewall));
                v.outgoingLinks.add(new Link(v, u, latency, bandwidth, firewall));
                totalBackdoors++;
                pw.println("Linked " + uId + " <-> " + vId + " with latency " + latency + "ms, bandwidth " + bandwidth + "Mbps, firewall " + firewall + ".");
            } else {
                pw.println("Some error occurred in link_backdoor.");
            }
        } catch (Exception e) {
            pw.println("Some error occurred in link_backdoor.");
        }
    }

    // Calculates the optimal path based on bandwidth and latency constraints
    private static void handleTraceRoute(StringTokenizer st, PrintWriter pw) {
        try {
            String srcId = st.nextToken();
            String dstId = st.nextToken();
            int minBandwidth = Integer.parseInt(st.nextToken());
            double lambda = Double.parseDouble(st.nextToken());

            Host src = network.get(srcId);
            Host dst = network.get(dstId);

            if (src != null && dst != null) {
                pw.println(Routing.findRoute(network, src, dst, minBandwidth, lambda));
            } else {
                pw.println("Some error occurred in trace_route.");
            }
        } catch (Exception e) {
            pw.println("Some error occurred in trace_route.");
        }
    }

    // Toggles the 'sealed' status of a link (logic-based removal)
    private static void handleSealBackdoor(StringTokenizer st, PrintWriter pw) {
        try {
            String uId = st.nextToken();
            String vId = st.nextToken();
            Host u = network.get(uId);
            Host v = network.get(vId);

            Link uv = null, vu = null;
            if (u != null) for (Link l : u.outgoingLinks) if (l.destination == v) uv = l;
            if (v != null) for (Link l : v.outgoingLinks) if (l.destination == u) vu = l;

            if (uv != null && vu != null) {
                uv.isSealed = !uv.isSealed;
                vu.isSealed = !vu.isSealed;
                totalBackdoors += uv.isSealed ? -1 : 1;
                pw.println("Backdoor " + uId + " <-> " + vId + (uv.isSealed ? " sealed." : " unsealed."));
            } else {
                pw.println("Some error occurred in seal_backdoor.");
            }
        } catch (Exception e) {
            pw.println("Some error occurred in seal_backdoor.");
        }
    }

    /**
     * Temporarily removes a host or link to check for Articulation Points or Bridges.
     */
    private static void handleSimulateBreach(StringTokenizer st, PrintWriter pw) {
        try {
            String arg1 = st.nextToken();
            String arg2 = st.hasMoreTokens() ? st.nextToken() : null;
            NetworkAnalysis analysis = new NetworkAnalysis(network);
            int initialComponents = analysis.countComponents();

            if (arg2 == null) {
                // Simulate Host (Node) failure
                Host h = network.get(arg1);
                if (h == null) throw new Exception();

                // Save and disconnect
                ArrayList<Link> savedLinks = new ArrayList<>(h.outgoingLinks);
                ArrayList<RemovedNeighborLink> backLinks = new ArrayList<>();
                network.remove(arg1);

                for (Link l : savedLinks) {
                    Host neighbor = l.destination;
                    neighbor.outgoingLinks.removeIf(bl -> {
                        if (bl.destination == h) {
                            backLinks.add(new RemovedNeighborLink(neighbor, bl));
                            return true;
                        }
                        return false;
                    });
                }

                int newComponents = analysis.countComponents();
                // Restore network state
                network.put(arg1, h);
                for (RemovedNeighborLink rl : backLinks) rl.neighbor.outgoingLinks.add(rl.linkToRemove);

                if (newComponents > initialComponents) {
                    pw.println("Host " + arg1 + " IS an articulation point.\nFailure results in " + newComponents + " disconnected components.");
                } else {
                    pw.println("Host " + arg1 + " is NOT an articulation point. Network remains the same.");
                }
            } else {
                // Simulate Link (Edge) failure
                Host u = network.get(arg1);
                Host v = network.get(arg2);
                Link uv = null, vu = null;
                if (u != null) for (Link l : u.outgoingLinks) if (l.destination == v) uv = l;
                if (v != null) for (Link l : v.outgoingLinks) if (l.destination == u) vu = l;

                if (uv != null && !uv.isSealed) {
                    uv.isSealed = true; vu.isSealed = true;
                    int newComp = analysis.countComponents();
                    uv.isSealed = false; vu.isSealed = false;

                    if (newComp > initialComponents) {
                        pw.println("Backdoor " + arg1 + " <-> " + arg2 + " IS a bridge.\nFailure results in " + newComp + " disconnected components.");
                    } else {
                        pw.println("Backdoor " + arg1 + " <-> " + arg2 + " is NOT a bridge. Network remains the same.");
                    }
                } else {
                    pw.println("Some error occurred in simulate_breach.");
                }
            }
        } catch (Exception e) {
            pw.println("Some error occurred in simulate_breach.");
        }
    }

    private static void handleScanConnectivity(PrintWriter pw) {
        int components = new NetworkAnalysis(network).countComponents();
        pw.println(components <= 1 ? "Network is fully connected." : "Network has " + components + " disconnected components.");
    }

    private static void handleOracleReport(PrintWriter pw) {
        new NetworkAnalysis(network).generateReport(totalBackdoors, pw);
    }

    // Helper class to store links during temporary removal for simulations
    private static class RemovedNeighborLink {
        Host neighbor;
        Link linkToRemove;
        public RemovedNeighborLink(Host n, Link l) { this.neighbor = n; this.linkToRemove = l; }
    }
}